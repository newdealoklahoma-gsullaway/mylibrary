<?php

declare(strict_types=1);

/*
 * Books Controller
 */

// Details request
if (isset($_GET['details'])) {

    require __DIR__ . '/details.php';
    exit;
}

// Action request
if (isset($_GET['action'])) {

    $action = $_GET['action'];

    switch ($action) {

        case 'add':
        case 'edit':
            require __DIR__ . '/form.php';
            break;

        case 'delete':
            // We will implement soft-delete later.
            require __DIR__ . '/form.php';
            break;

        default:
            http_response_code(400);
            die('Invalid book action.');
    }

    exit;
}

// Default action = view
require __DIR__ . '/view.php';