<?php

declare(strict_types=1);


/*
|--------------------------------------------------------------------------
| Load .env
|--------------------------------------------------------------------------
*/

$envFile = dirname(__DIR__) . '/.env';

if (!is_readable($envFile)) {
    die('Configuration file (.env) not found.');
}


$env = [];

$lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

foreach ($lines as $line) {

    $line = trim($line);

    // Ignore comments
    if ($line === '' || str_starts_with($line, '#')) {
        continue;
    }

    if (!str_contains($line, '=')) {
        continue;
    }

    [$key, $value] = explode('=', $line, 2);

    $key = trim($key);
    $value = trim($value);

    // Remove optional quotes
    $value = trim($value, "\"'");

    $env[$key] = $value;
}


/*
|--------------------------------------------------------------------------
| Database Configuration
|--------------------------------------------------------------------------
*/

$dbHost = $env['DB_HOST'] ?? 'localhost';
$dbName = $env['DB_NAME'] ?? '';
$dbUser = $env['DB_USER'] ?? '';
$dbPass = $env['DB_PASS'] ?? '';
$dbCharset = $env['DB_CHARSET'] ?? 'utf8mb4';


/*
|--------------------------------------------------------------------------
| Validate Configuration
|--------------------------------------------------------------------------
*/

if ($dbName === '' || $dbUser === '') {
    die('Database configuration is incomplete.');
}


/*
|--------------------------------------------------------------------------
| PDO Connection
|--------------------------------------------------------------------------
*/

$dsn = "mysql:host={$dbHost};dbname={$dbName};charset={$dbCharset}";

try {

    $pdo = new PDO(
        $dsn,
        $dbUser,
        $dbPass,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false
        ]
    );

} catch (PDOException $e) {

    if (($env['APP_ENV'] ?? '') === 'development') {

        die(
            'Database connection failed: '
            . htmlspecialchars($e->getMessage())
        );

    }

    die('Database connection failed.');

}