<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| Application Configuration
|--------------------------------------------------------------------------
|
| This file is loaded by index.php before the application is routed.
| Keep application-wide settings here.
|
*/


/*
|--------------------------------------------------------------------------
| Load Environment Variables
|--------------------------------------------------------------------------
*/

$envFile = dirname(__DIR__) . '/.env';

if (!is_readable($envFile)) {
    die('Application configuration file (.env) not found.');
}

$env = [];

$lines = file(
    $envFile,
    FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES
);

foreach ($lines as $line) {

    $line = trim($line);

    // Ignore blank lines and comments
    if ($line === '' || str_starts_with($line, '#')) {
        continue;
    }

    // Ignore malformed lines
    if (!str_contains($line, '=')) {
        continue;
    }

    [$key, $value] = explode('=', $line, 2);

    $key   = trim($key);
    $value = trim($value);

    // Remove optional quotes
    $value = trim($value, "\"'");

    $env[$key] = $value;
}


/*
|--------------------------------------------------------------------------
| Application Environment
|--------------------------------------------------------------------------
*/

define('APP_ENV', $env['APP_ENV'] ?? 'production');

define(
    'APP_DEBUG',
    filter_var(
        $env['APP_DEBUG'] ?? false,
        FILTER_VALIDATE_BOOLEAN
    )
);


/*
|--------------------------------------------------------------------------
| Application Paths
|--------------------------------------------------------------------------
*/

define('APP_ROOT', dirname(__DIR__));

define('APP_URL', $env['APP_URL'] ?? '/mylibrary');


/*
|--------------------------------------------------------------------------
| Error Reporting
|--------------------------------------------------------------------------
*/

if (APP_DEBUG) {

    error_reporting(E_ALL);

    ini_set('display_errors', '1');
    ini_set('display_startup_errors', '1');

} else {

    error_reporting(E_ALL);

    ini_set('display_errors', '0');
    ini_set('display_startup_errors', '0');
}


/*
|--------------------------------------------------------------------------
| Time Zone
|--------------------------------------------------------------------------
*/

date_default_timezone_set(
    $env['APP_TIMEZONE'] ?? 'America/Chicago'
);


/*
|--------------------------------------------------------------------------
| Application Name
|--------------------------------------------------------------------------
*/

define(
    'APP_NAME',
    $env['APP_NAME'] ?? 'MyLibrary'
);


/*
|--------------------------------------------------------------------------
| Database Connection
|--------------------------------------------------------------------------
|
| dbc.php is responsible only for establishing the PDO connection.
|
*/

require_once APP_ROOT . '/config/dbc.php';